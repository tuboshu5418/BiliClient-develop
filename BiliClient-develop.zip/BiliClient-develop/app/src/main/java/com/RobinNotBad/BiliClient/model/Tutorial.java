package com.RobinNotBad.BiliClient.model;

import java.util.List;

public class Tutorial {
    public String name;
    public String description;
    public String imgid;
    public int type;
    public List<CustomText> content;
}
