package com.RobinNotBad.BiliClient.model;

public class Announcement {
    public int id;
    public String ctime;
    public String title;
    public String content;

    public Announcement() {
    }
}
