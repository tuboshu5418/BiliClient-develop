package com.RobinNotBad.BiliClient.model;

public class CustomText {
    public int type; //用于标识普通文本或换行
    public String text; //内容
    public String style; //文本样式
    public String color; //文本颜色(rgb字符串)

    public CustomText() {
    }
}
