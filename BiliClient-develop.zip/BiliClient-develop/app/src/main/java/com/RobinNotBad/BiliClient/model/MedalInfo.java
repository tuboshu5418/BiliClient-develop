package com.RobinNotBad.BiliClient.model;

import java.io.Serializable;

public class MedalInfo implements Serializable {
    public long target_id;
    public int level;
    public String medal_name;
    public int medal_color_start;
    public int medal_color_end;
    public int medal_color_border;
    public int guard_level;
    public int wearing_status;
    public long medal_id;
    public int intimacy;
    public int next_intimacy;
    public int today_feed;
    public int day_limit;
    public String guard_icon;
    public String honor_icon;
    public String target_name;
    public String target_icon;
    public String link;
    public int live_status;
    public int offical;
    public String uinfo_medal_name;
    public int uinfo_medal_level;
    public int uinfo_medal_color_start;
    public int uinfo_medal_color_end;
    public int uinfo_medal_color_border;
    public int uinfo_medal_color;
    public long uinfo_medal_id;
    public int uinfo_medal_typ;
    public int uinfo_medal_is_light;
    public long uinfo_medal_ruid;
    public int uinfo_medal_guard_level;
    public int uinfo_medal_score;
    public String uinfo_medal_guard_icon;
    public String uinfo_medal_honor_icon;
    public String v2_medal_color_start;
    public String v2_medal_color_end;
    public String v2_medal_color_border;
    public String v2_medal_color_text;
    public String v2_medal_color_level;
    public int user_receive_count;
}

