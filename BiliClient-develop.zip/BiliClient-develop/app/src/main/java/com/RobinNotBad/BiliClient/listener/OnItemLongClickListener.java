package com.RobinNotBad.BiliClient.listener;

public interface OnItemLongClickListener {
    void onItemLongClick(int position);
}
