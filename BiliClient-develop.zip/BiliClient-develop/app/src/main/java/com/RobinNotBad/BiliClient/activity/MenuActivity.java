package com.RobinNotBad.BiliClient.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.lifecycle.Lifecycle;

import com.RobinNotBad.BiliClient.BiliTerminal;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.activity.base.InstanceActivity;
import com.RobinNotBad.BiliClient.activity.dynamic.DynamicActivity;
import com.RobinNotBad.BiliClient.activity.live.RecommendLiveActivity;
import com.RobinNotBad.BiliClient.activity.message.MessageActivity;
import com.RobinNotBad.BiliClient.activity.search.SearchActivity;
import com.RobinNotBad.BiliClient.activity.settings.SettingMainActivity;
import com.RobinNotBad.BiliClient.activity.settings.login.LoginActivity;
import com.RobinNotBad.BiliClient.activity.user.MySpaceActivity;
import com.RobinNotBad.BiliClient.activity.video.PopularActivity;
import com.RobinNotBad.BiliClient.activity.video.PreciousActivity;
import com.RobinNotBad.BiliClient.activity.video.RankingActivity;
import com.RobinNotBad.BiliClient.activity.video.RecommendActivity;
import com.RobinNotBad.BiliClient.activity.video.TimelineActivity;
import com.RobinNotBad.BiliClient.activity.video.local.LocalListActivity;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

//菜单页面
//2023-07-14

public class MenuActivity extends BaseActivity {

    private String from;
    private MaterialButton dynamicButton;
    private MaterialButton messageButton;

    /**
     * 在排序设置和Splash中使用到的，
     * 需要使用排序，故用了LinkedHashMap
     * 请不要让它的顺序被打乱（
     */
    public static final Map<String, Pair<String, Class<? extends InstanceActivity>>> btnNames = new LinkedHashMap<>() {{
        put("recommend", new Pair<>("推荐", RecommendActivity.class));
        put("popular", new Pair<>("热门", PopularActivity.class));
        put("precious", new Pair<>("入站必刷", PreciousActivity.class));
        put("ranking", new Pair<>("全站排行榜", RankingActivity.class));
        put("live", new Pair<>("直播", RecommendLiveActivity.class));
        put("timeline", new Pair<>("时间线", TimelineActivity.class));
        put("search", new Pair<>("搜索", SearchActivity.class));
        put("dynamic", new Pair<>("动态", DynamicActivity.class));
        put("myspace", new Pair<>("我的", MySpaceActivity.class));
        put("message", new Pair<>("消息", MessageActivity.class));
        put("local", new Pair<>("缓存", LocalListActivity.class));
        put("settings", new Pair<>("设置", SettingMainActivity.class));
    }};

    long time;

    @SuppressLint({"MissingInflatedId", "InflateParams"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        time = System.currentTimeMillis();
        Log.e("debug", "MenuActivity onCreate: " + time);

        Intent intent = getIntent();
        from = intent.getStringExtra("from");
        if (from != null) {
            Log.d("debug-menu", from);
            if (btnNames.containsKey(from))
                setPageName(Objects.requireNonNull(btnNames.get(from)).first);
        }

        findViewById(R.id.top).setOnClickListener(view -> finish());

        List<String> btnList;

        String sortConf = SharedPreferencesUtil.getString(SharedPreferencesUtil.MENU_SORT, "");
        Log.e("debug_sort", sortConf);

        if (!TextUtils.isEmpty(sortConf)) {
            String[] splitName = sortConf.split(";");
            if (splitName.length != btnNames.size()) {
                btnList = getDefaultSortList();
            } else {
                btnList = new ArrayList<>();
                for (String name : splitName) {
                    if (!btnNames.containsKey(name)) {
                        btnList = getDefaultSortList();
                        break;
                    } else {
                        btnList.add(name);
                    }
                }
            }
        } else {
            btnList = getDefaultSortList();
        }

        if (SharedPreferencesUtil.getLong(SharedPreferencesUtil.mid, 0) == 0) {
            btnList.add(0, "login");
            btnList.remove("dynamic");
            btnList.remove("message");
            btnList.remove("myspace");
        }

        if (!SharedPreferencesUtil.getBoolean("menu_popular", true)) btnList.remove("popular");
        if (!SharedPreferencesUtil.getBoolean("menu_precious", false)) btnList.remove("precious");
        if (!SharedPreferencesUtil.getBoolean("menu_ranking", false)) btnList.remove("ranking");
        if (!SharedPreferencesUtil.getBoolean("menu_live", false)) btnList.remove("live");
        if (!SharedPreferencesUtil.getBoolean("menu_timeline", false)) btnList.remove("timeline");

        btnList.add("exit"); //如果你希望用户手动把退出按钮排到第一个（

        LinearLayout layout = findViewById(R.id.menu_layout);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        for (String btn : btnList) {
            MaterialButton materialButton = new MaterialButton(this);
            switch (btn) {
                case "exit":
                    materialButton.setText("退出");
                    break;
                case "login":
                    materialButton.setText("登录");
                    break;
                case "dynamic":
                    String btnText = Objects.requireNonNull(btnNames.get(btn)).first;
                    if (btn.equals("dynamic")) {
                        dynamicButton = materialButton;
                        int updateNum = SharedPreferencesUtil.getInt(SharedPreferencesUtil.DYNAMIC_UPDATE_NUM, 0);
                        if (updateNum > 0) {
                            btnText = btnText + " (" + updateNum + ")";
                        }
                    }
                    materialButton.setText(btnText);
                    break;
                case "message":
                    String messageBtnText = Objects.requireNonNull(btnNames.get(btn)).first;
                    messageButton = materialButton;
                    int messageUpdateNum = SharedPreferencesUtil.getInt(SharedPreferencesUtil.MESSAGE_UPDATE_NUM, 0);
                    if (messageUpdateNum > 0) {
                        messageBtnText = messageBtnText + " (" + messageUpdateNum + ")";
                    }
                    materialButton.setText(messageBtnText);
                    break;
                default:
                    materialButton.setText(Objects.requireNonNull(btnNames.get(btn)).first);
                    break;
            }
            materialButton.setOnClickListener(view -> killAndJump(btn));
            layout.addView(materialButton, params);
        }

        Log.e("debug", "MenuActivity onCreate in: " + (System.currentTimeMillis() - time));
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("debug", "MenuActivity onStart in: " + (System.currentTimeMillis() - time));
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("debug", "MenuActivity onResume in: " + (System.currentTimeMillis() - time));
        if (dynamicButton != null) {
            String btnText = Objects.requireNonNull(btnNames.get("dynamic")).first;
            int updateNum = SharedPreferencesUtil.getInt(SharedPreferencesUtil.DYNAMIC_UPDATE_NUM, 0);
            if (updateNum > 0) {
                btnText = btnText + " (" + updateNum + ")";
            }
            dynamicButton.setText(btnText);
        }
        if (messageButton != null) {
            String messageBtnText = Objects.requireNonNull(btnNames.get("message")).first;
            int messageUpdateNum = SharedPreferencesUtil.getInt(SharedPreferencesUtil.MESSAGE_UPDATE_NUM, 0);
            if (messageUpdateNum > 0) {
                messageBtnText = messageBtnText + " (" + messageUpdateNum + ")";
            }
            messageButton.setText(messageBtnText);
        }
    }

    private void killAndJump(String name) {
        if (btnNames.containsKey(name) && !Objects.equals(name, from)) {
            InstanceActivity instance = BiliTerminal.getInstanceActivityOnTop();
            if (instance != null && instance.getLifecycle().getCurrentState() != Lifecycle.State.DESTROYED)
                instance.finish();

            Intent intent = new Intent();
            intent.setClass(MenuActivity.this, Objects.requireNonNull(btnNames.get(name)).second);
            intent.putExtra("from", name);
            startActivity(intent);
            Glide.get(BiliTerminal.context).clearMemory();
        } else {
            switch (name) {
                case "exit": //退出按钮
                    InstanceActivity instance = BiliTerminal.getInstanceActivityOnTop();
                    if (instance != null && !instance.isDestroyed()) instance.finish();
                    Process.killProcess(Process.myPid());
                    break;
                case "login": //登录按钮
                    Intent intent = new Intent();
                    intent.setClass(MenuActivity.this, LoginActivity.class);
                    startActivity(intent);
                    break;
            }
        }
        finish();
    }

    private List<String> getDefaultSortList() {
        return new ArrayList<>() {{
            add("recommend");
            add("popular");
            add("precious");
            add("ranking");
            add("live");
            add("timeline");
            add("search");
            add("dynamic");
            add("myspace");
            add("message");
            add("local");
            add("settings");
        }};
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) finish();
        return super.onKeyDown(keyCode, event);
    }
}

