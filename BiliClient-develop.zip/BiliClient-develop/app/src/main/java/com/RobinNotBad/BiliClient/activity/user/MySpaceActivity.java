package com.RobinNotBad.BiliClient.activity.user;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.InstanceActivity;
import com.RobinNotBad.BiliClient.activity.settings.login.LoginActivity;
import com.RobinNotBad.BiliClient.activity.user.favorite.FavoriteFolderListActivity;
import com.RobinNotBad.BiliClient.activity.user.info.UserInfoActivity;
import com.RobinNotBad.BiliClient.api.UserInfoApi;
import com.RobinNotBad.BiliClient.model.UserInfo;
import com.RobinNotBad.BiliClient.util.CenterThreadPool;
import com.RobinNotBad.BiliClient.util.GlideUtil;
import com.RobinNotBad.BiliClient.util.MsgUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.RobinNotBad.BiliClient.util.StringUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.card.MaterialCardView;

public class MySpaceActivity extends InstanceActivity {

    private ImageView userAvatar;
    private TextView userName, userFans, userExp;
    private MaterialCardView myInfo, follow, watchLater, favorite, bangumi, history, creative, vip, loginRecord, coinLog, expLog, editSign, logout;

    private boolean confirmLogout = false;
    private UserInfo currentUserInfo;

    @SuppressLint({"SetTextI18n", "InflateParams"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        asyncInflate(R.layout.activity_myspace, (layoutView, resId) -> {
            Log.e("debug", "进入个人页");

            userAvatar = findViewById(R.id.userAvatar);
            userName = findViewById(R.id.userName);
            userFans = findViewById(R.id.userFans);
            userExp = findViewById(R.id.userExp);

            myInfo = findViewById(R.id.myinfo);
            follow = findViewById(R.id.follow);
            watchLater = findViewById(R.id.watchlater);
            favorite = findViewById(R.id.favorite);
            bangumi = findViewById(R.id.bangumi);
            history = findViewById(R.id.history);
            creative = findViewById(R.id.creative);
            vip = findViewById(R.id.vip);
            loginRecord = findViewById(R.id.login_record);
            coinLog = findViewById(R.id.coin_log);
            expLog = findViewById(R.id.exp_log);
            editSign = findViewById(R.id.edit_sign);
            logout = findViewById(R.id.logout);


            CenterThreadPool.run(() -> {
                try {
                    UserInfo userInfo = UserInfoApi.getCurrentUserInfo();
                    currentUserInfo = userInfo;
                    int userCoin = UserInfoApi.getCurrentUserCoin();
                    if (!this.isDestroyed()) runOnUiThread(() -> {
                        Glide.with(MySpaceActivity.this).load(GlideUtil.url(userInfo.avatar))
                                .transition(GlideUtil.getTransitionOptions())
                                .placeholder(R.mipmap.akari).apply(RequestOptions.circleCropTransform())
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .into(userAvatar);
                        userName.setText(userInfo.name);
                        userFans.setText(StringUtil.toWan(userInfo.fans) + "粉丝 " + userCoin + "硬币");
                        userExp.setText("EXP:" + userInfo.current_exp + (userInfo.level >= 6 ? "" : "/" + userInfo.next_exp));

                        myInfo.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, UserInfoActivity.class);
                            intent.putExtra("mid", userInfo.mid);
                            startActivity(intent);
                        });

                        follow.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, FollowUsersActivity.class);
                            intent.putExtra("mid", userInfo.mid);
                            intent.putExtra("mode", 0);
                            startActivity(intent);
                        });

                        watchLater.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, WatchLaterActivity.class);
                            startActivity(intent);
                        });

                        favorite.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, FavoriteFolderListActivity.class);
                            startActivity(intent);
                        });

                        bangumi.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, FollowingBangumisActivity.class);
                            startActivity(intent);
                        });

                        history.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, HistoryActivity.class);
                            startActivity(intent);
                        });

                        creative.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, CreativeCenterActivity.class);
                            startActivity(intent);
                        });
                        if (!SharedPreferencesUtil.getBoolean("creative_enable", true))
                            creative.setVisibility(View.GONE);

                        vip.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, VipActivity.class);
                            startActivity(intent);
                        });

                        loginRecord.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, LoginRecordActivity.class);
                            startActivity(intent);
                        });

                        coinLog.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, CoinLogActivity.class);
                            startActivity(intent);
                        });

                        expLog.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, ExpLogActivity.class);
                            startActivity(intent);
                        });

                        editSign.setOnClickListener(view -> {
                            Intent intent = new Intent();
                            intent.setClass(MySpaceActivity.this, EditSignActivity.class);
                            intent.putExtra("currentSign", userInfo.sign);
                            startActivity(intent);
                        });

                        logout.setOnClickListener(view -> {
                            if (confirmLogout) {
                                CenterThreadPool.run(UserInfoApi::exitLogin);
                                SharedPreferencesUtil.removeValue(SharedPreferencesUtil.cookies);
                                SharedPreferencesUtil.removeValue(SharedPreferencesUtil.mid);
                                SharedPreferencesUtil.removeValue(SharedPreferencesUtil.csrf);
                                SharedPreferencesUtil.removeValue(SharedPreferencesUtil.refresh_token);
                                SharedPreferencesUtil.removeValue(SharedPreferencesUtil.cookie_refresh);
                                MsgUtil.showMsg("账号已退出");
                                Intent intent = new Intent(this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            } else MsgUtil.showMsg("再点一次退出登录！");
                            confirmLogout = !confirmLogout;
                        });

                        View scrollView = findViewById(R.id.scrollView);
                        scrollView.setFocusable(true);
                        scrollView.setFocusableInTouchMode(true);
                        scrollView.requestFocus();
                    });
                } catch (Exception e) {
                    report(e);
                }
            });
        });
    }
}