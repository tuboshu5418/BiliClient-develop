package com.RobinNotBad.BiliClient.model;

public class FollowTag {
    public int tagid;
    public String name;
    public int count;

    public FollowTag(int tagid, String name, int count) {
        this.tagid = tagid;
        this.name = name;
        this.count = count;
    }
}

