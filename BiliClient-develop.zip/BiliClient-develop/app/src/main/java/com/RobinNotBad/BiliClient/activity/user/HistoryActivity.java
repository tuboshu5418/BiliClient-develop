package com.RobinNotBad.BiliClient.activity.user;

import android.os.Bundle;

import com.RobinNotBad.BiliClient.activity.base.RefreshListActivity;
import com.RobinNotBad.BiliClient.adapter.video.VideoCardAdapter;
import com.RobinNotBad.BiliClient.api.HistoryApi;
import com.RobinNotBad.BiliClient.model.ApiResult;
import com.RobinNotBad.BiliClient.model.VideoCard;
import com.RobinNotBad.BiliClient.util.CenterThreadPool;
import com.RobinNotBad.BiliClient.util.MsgUtil;
import android.view.View;
import android.widget.TextView;
import com.RobinNotBad.BiliClient.R; // 你的项目包名，和LocalListActivity里一致
import java.util.ArrayList;
import java.util.List;

//历史记录
//2023-08-18
//2024-04-30

public class HistoryActivity extends RefreshListActivity {

    private ApiResult lastResult = new ApiResult();
    private ArrayList<VideoCard> videoList;
    private int longClickPosition = -1;
    private long longClickTimestamp;
    private TextView emptyTip;
    private VideoCardAdapter videoCardAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setPageName("历史记录");

        emptyTip = findViewById(R.id.emptyTip);

        recyclerView.setHasFixedSize(true);

        videoList = new ArrayList<>();

        CenterThreadPool.run(() -> {
            try {
                lastResult = HistoryApi.getHistory(lastResult, videoList);
                if (lastResult.code == 0) {
                    videoCardAdapter = new VideoCardAdapter(this, videoList);
                    // 设置长按删除
                    videoCardAdapter.setOnLongClickListener(position -> {
                        long now = System.currentTimeMillis();
                        if (longClickPosition == position && now - longClickTimestamp < 4000) {
                            // 第二次长按：删除
                            deleteOneHistory(position);
                            longClickPosition = -1;
                        } else {
                            longClickPosition = position;
                            longClickTimestamp = now;
                            MsgUtil.showMsg("再次长按删除");
                        }
                    });
                    setOnLoadMoreListener(this::continueLoading);
                    setRefreshing(false);
                    setAdapter(videoCardAdapter);

                    if (lastResult.isBottom) {
                        setBottom(true);
                    }
                } else MsgUtil.showMsg(lastResult.message);

            } catch (Exception e) {
                loadFail(e);
            }
        });
    }

    private void continueLoading(int page) {
        CenterThreadPool.run(() -> {
            try {
                List<VideoCard> list = new ArrayList<>();
                lastResult = HistoryApi.getHistory(lastResult, list);
                if (lastResult.code == 0) {
                    runOnUiThread(() -> {
                        videoList.addAll(list);
                        videoCardAdapter.notifyItemRangeInserted(videoList.size() - list.size(), list.size());
                    });
                    if (lastResult.isBottom) {
                        setBottom(true);
                    }
                    checkEmpty();
                }
                setRefreshing(false);
            } catch (Exception e) {
                loadFail(e);
            }
        });
    }
    private void deleteOneHistory(int position) {
        if (position < 0 || position >= videoList.size()) return;
        VideoCard card = videoList.get(position);

        CenterThreadPool.run(() -> {
            try {
                // 调用删除接口
                ApiResult result = HistoryApi.deleteHistory(card);
                runOnUiThread(() -> {
                    if (result.code == 0) {
                        videoList.remove(position);
                        videoCardAdapter.notifyItemRemoved(position);
                        videoCardAdapter.notifyItemRangeChanged(position, videoList.size() - position);
                        MsgUtil.showMsg("删除成功");
                        checkEmpty();
                    } else {
                        MsgUtil.showMsg("删除失败：" + result.message);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> MsgUtil.showMsg("删除异常"));
            }
        });
    }
    private void checkEmpty() {
        runOnUiThread(() -> {
            if (emptyTip != null) {
                emptyTip.setVisibility(videoList.isEmpty() ? View.VISIBLE : View.GONE);
            }
        });
    }
}