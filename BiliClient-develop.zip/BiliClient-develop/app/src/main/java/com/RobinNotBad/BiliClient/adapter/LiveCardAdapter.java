package com.RobinNotBad.BiliClient.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.adapter.video.VideoCardHolder;
import com.RobinNotBad.BiliClient.listener.OnItemLongClickListener;
import com.RobinNotBad.BiliClient.model.LiveRoom;
import com.RobinNotBad.BiliClient.model.VideoCard;
import com.RobinNotBad.BiliClient.util.StringUtil;
import com.RobinNotBad.BiliClient.util.TerminalContext;

import java.util.List;

public class LiveCardAdapter extends RecyclerView.Adapter<VideoCardHolder> {

    final Context context;
    final List<LiveRoom> roomList;
    OnItemLongClickListener longClickListener;

    public LiveCardAdapter(Context context, List<LiveRoom> roomList) {
        this.context = context;
        this.roomList = roomList;
    }

    public void setOnLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    @NonNull
    @Override
    public VideoCardHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.cell_video_list, parent, false);
        return new VideoCardHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoCardHolder holder, int position) {
        if (position < 0 || position >= roomList.size())
            return;
        LiveRoom room = roomList.get(position);
        if (room == null)
            return;

        VideoCard videoCard = new VideoCard();
        videoCard.title = StringUtil.removeHtml(room.title);
        if (room.user_cover != null && !room.user_cover.startsWith("http"))
            videoCard.cover = "http:" + room.user_cover;
        else
            videoCard.cover = room.user_cover;
        if (TextUtils.isEmpty(videoCard.cover) || videoCard.cover.equals("http:"))
            videoCard.cover = room.cover;
        videoCard.upName = room.uname;
        videoCard.view = StringUtil.toWan(room.online) + "人观看";
        videoCard.type = "live";

        holder.showVideoCard(videoCard, context);

        holder.itemView
                .setOnClickListener(view -> TerminalContext.getInstance().enterLiveDetailPage(context, room.roomid));

        holder.itemView.setOnLongClickListener(view -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(position);
                return true;
            } else
                return false;
        });
    }

    @Override
    public int getItemCount() {
        return roomList != null ? roomList.size() : 0;
    }

}
