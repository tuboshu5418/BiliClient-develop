package com.RobinNotBad.BiliClient.listener;

public interface OnItemClickListener {
    void onItemClick(int position);
}
