package com.RobinNotBad.BiliClient.model;

public class PageInfo {
    public int page_num;
    public int require_ps;
    public int total;
    public int return_ps;
}
