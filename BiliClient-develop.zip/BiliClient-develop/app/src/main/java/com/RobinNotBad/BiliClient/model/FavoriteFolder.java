package com.RobinNotBad.BiliClient.model;

public class FavoriteFolder {
    public long id;
    public long mediaId;
    public String name;
    public String cover;
    public int videoCount;
    public int maxCount;
    public boolean isDefault;

    public FavoriteFolder() {
    }
}
