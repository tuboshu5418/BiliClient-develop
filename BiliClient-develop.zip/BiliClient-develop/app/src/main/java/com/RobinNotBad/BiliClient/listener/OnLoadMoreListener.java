package com.RobinNotBad.BiliClient.listener;

public interface OnLoadMoreListener {
    void onLoad(int page);
}
